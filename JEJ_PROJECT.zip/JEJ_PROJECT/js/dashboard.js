$(document).ready(function(){
    doRequest();
});

var doRequest=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data: {choice:'viewUser'},
        success: function(data)
        {
            var json = JSON.parse(data);
            var str = "";
            let ctr = 1;
            json.forEach(element => {
                str += "<tr>";
                str += "<td>"+ctr+"</td>";
                str += "<td>"+element.fname+"</td>";
                str += "<td>"+element.lname+"</td>";
                str += "<td>"+element.mname+"</td>";
                str += "<td>"+element.address+"</td>";
                str += "<td>"+element.contact_number+"</td>";
                str += "<td>"+element.email+"</td>";
                str += "<td><button onclick='update("+element.user_id+")'>Update</button><button onclick='deleteUser("+element.user_id+")'>Delete</button></td>";
                ctr++;
            });
            $('#user_tbl').append(str);
        },
        error: function(error)
        {
            alert(error);
        } 
    })
}
var update=(user_id)=>
{
    localStorage.setItem('user_id',user_id);
    location.replace("updateInformation.html");
}
var deleteUser=(user_id)=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data: { choice: 'deleteInformation', user_id: user_id },
        success: function (result) {
            if (result == 200) {
                location.reload();
            }
        },
        error: function (error) {
            alert(error);
        }
    })
}
var doLogout=()=>
 {
     $.ajax({
         type: "POST",
         url: "include/router.php",
         data:{choice:'logout'},
         success: function(res)
         {
             if(res==200)
             {
                location.replace("index.html");
             }
         },
         error: function(error)
         {
            alert(error);
         }
     })
 }