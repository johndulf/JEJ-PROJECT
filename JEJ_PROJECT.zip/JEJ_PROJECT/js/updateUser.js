if($('#btn-update').click(function(){
	checkUser();
}));

var checkUser=()=>
{
    if($('#fname').val() != "" && $('#lname').val() != "" && 
       $('#mname').val() != "" && $('#address').val() != "" && $('#cnumber').val() != "" && $('#email').val() != "")
    {
        doReset();
    }
    else
    {
        alert("Please Fill in all the field's");
    }
}

var doReset=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data:{choice:'updateInformation',user_id:localStorage.getItem('user_id'),fname:$('#fname').val(),lname:$('#lname').val(),
        mname:$('#mname').val(),address:$('#address').val(),cnumber:$('#cnumber').val(),email:$('#email').val()},
        success: function(res)
        {
            if(res == 200)
            {
                alert("Update Successfully");
                location.replace("dashboard.html");
            }
        },
        error: function(error)
        {
            alert(error);
        }
    })
}