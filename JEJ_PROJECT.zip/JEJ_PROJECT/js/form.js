const signInBtn = document.getElementById("signIn");
const signUpBtn = document.getElementById("signUp");
const fistForm = document.getElementById("form1");
const secondForm = document.getElementById("form2");
const container = document.querySelector(".container");

signInBtn.addEventListener("click", () => {
	container.classList.remove("right-panel-active");
});

signUpBtn.addEventListener("click", () => {
	container.classList.add("right-panel-active");
});

fistForm.addEventListener("submit", (e) => e.preventDefault());
secondForm.addEventListener("submit", (e) => e.preventDefault());


if($('#btn-reg').click(function(){
	checkValid();
}));

if($('#btn-login').click(function(){
    checkUser();
}));

var checkValid=()=>
{
    if($('#user').val() != "" && $('#pass').val() != "" &&
    $('#fname').val() != "" && $('#lname').val() != "" &&
    $('#mname').val() != "" && $('#address').val() != "" && $('#mobile_no').val() != "" &&
    $('#email').val() != "")
    {
        doRequest();
    }
    else
    {
        alert("Please Fill in all the field's");
    }
}

var checkUser=()=>
{
    if($('#username').val() != "" && $('#password').val() != "")
    {
        doLogin();
    }
    else
    {
        alert("Please Fill in all the field's");
    }
}

var doRequest=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data:{choice:'register', user:$('#user').val(),pass:$('#pass').val(),fname:$('#fname').val(),lname:$('#lname').val(),
        mname:$('#mname').val(),address:$('#address').val(),mobile_no:$('#mobile_no').val(),email:$('#email').val()},
        success: function(result)
        {
            if(result == 200)
            {
                alert("Account has been Created!");
                location.reload();
            }
            else
            {
                alert("Username already been use please choose other username");
            }
        },
        error: function(error)
        {

            alert(error);
        }
    })
}

let loginAttempt = 3;
var doLogin=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data:{choice:'login', username:$('#username').val(),password:$('#password').val()},
        success: function(result)
        {  
            if(result == "client")
            {
                location.replace("afterIndex.html");
            }
            else if(result == "admin")
            {
                location.replace("dashboard.html");
            }
            else if(result ==  "lock")
            {
                alert("no more attempt left");
            }
            else
            {
                if(loginAttempt == 0)
                {
                    let attempt = 1;
                    alert("No More Login Attempt");
                    doLocked(attempt);
                }
                else
                {
                    loginAttempt -= 1;
                    alert("Incorrect Username and Password");
                    if(loginAttempt == 0)
                    {
                        document.getElementById("username").disabled = true;
                        document.getElementById("password").disabled = true;
                    }
                }
            }
        },
        error: function(error)
        {
            alert(error);
        }
    })
}

var doLocked=(attempt)=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data:{choice:'lockUser', attempt:attempt, username:$('#username').val()},
        success: function(data)
        {
            console.log("");
        },
        error: function(error)
        {
            alert(error);
        }
    })
}