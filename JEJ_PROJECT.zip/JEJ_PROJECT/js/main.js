$(document).ready(function(){
    doRequest();
});

var doRequest=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data: {choice:'viewReserve'},
        success: function(data)
        {
            var json = JSON.parse(data);
            var str = "";
            let ctr = 1;
            json.forEach(element => {
                str += "<tr>";
                str += "<td>"+ctr+"</td>";
                str += "<td>"+element.name+"</td>";
                str += "<td>"+element.email+"</td>";
                str += "<td>"+element.date+"</td>";
                str += "<td>"+element.time+"</td>";
                str += "<td>"+element.person+"</td>";
                ctr++;
            });
            $('#tbl_reserve').append(str);
        },
        error: function(error)
        {
            alert(error);
        } 
    })
}

var doLogout=()=>
 {
     $.ajax({
         type: "POST",
         url: "include/router.php",
         data:{choice:'logout'},
         success: function(res)
         {
             if(res==200)
             {
                location.replace("index.html");
             }
         },
         error: function(error)
         {
            alert(error);
         }
     })
 }