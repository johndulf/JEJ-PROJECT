if($('#btn-update').click(function(){
	checkUser();
}));

var checkUser=()=>
{
    if($('#user').val() != "" && $('#pass').val() != "" && $('#npass').val() != "")
    {
        doReset();
    }
    else
    {
        alert("Please Fill in all the field's");
    }
}

var doReset=()=>
{
    $.ajax({
        type: "POST",
        url: "include/router.php",
        data:{choice:'reset', user:$('#user').val(),pass:$('#pass').val(),npass:$('#npass').val()},
        success: function(res)
        {
            if(res == 1)
            {
                alert("Password Updated!");
                location.replace("afterIndex.html");
            }
        },
        error: function(error)
        {
            alert(error);
        }
    })
}