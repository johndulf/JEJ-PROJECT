<?php
require_once('database.php');
class backend
{

    //return to router
    public function doRegister($user, $pass, $fname, $lname, $mname, $address, $mobile_no, $email)
    {
        return self::register($user, $pass, $fname, $lname, $mname, $address, $mobile_no, $email);
    }
    public function doLogin($username, $password)
    {
        return self::login($username, $password);
    }
    public function doReset($username, $password, $new_password)
    {
        return self::reset($username, $password, $new_password);
    }
    public function doBook($coffee, $price, $type)
    {
        return self::coffee($coffee, $price, $type);
    }
    public function doMessage($name, $email, $subject, $message)
    {
        return self::message($name, $email, $subject, $message);
    }
    public function doReserve($name, $email, $date, $time, $person)
    {
        return self::reserved($name, $email, $date, $time, $person);
    }
    public function doViewReserve()
    {
        return self::viewReserve();
    }
    public function doViewUser()
    {
        return self::viewUser();
    }

    public function doLockUser($attempt,$username)
    {
        return self::lockUser($attempt,$username);
    }

    public function doViewCoffee()
    {
        return self::viewCoffee();
    }

    public function deleteUser($user_id)
    {
        return self::deleteInfo($user_id);
    }

    public function deleteCoffee($id)
    {
        return self::deleteCoff($id);
    }

    public function updateUser($user_id, $fname, $lname, $mname, $address, $cnumber, $email)
    {
        return self::updateInformation($user_id, $fname, $lname, $mname, $address, $cnumber, $email);
    }
    //end


    //checklist
    private function checker($user, $pass, $fname, $lname, $mname, $address, $mobile_no, $email)
    {
        if (
            $user != "" && $pass != "" && $fname != "" && $lname != "" && $mname != "" &&
            $address != "" && $mobile_no != "" && $email != ""
        ) {
            return true;
        } else {
            return false;
        }
    }

    private function checkUser($username, $password)
    {
        if ($username != "" && $password != "") {
            return true;
        } else {
            return false;
        }
    }
    private function checkResetCredentials($username, $password, $new_password)
    {
        if ($username != "" && $password != "" && $new_password != "") {
            return true;
        } else {
            return false;
        }
    }

    private function ifValid($coffee, $price, $type)
    {
        if ($coffee != "" && $price != "" && $type != "") {
            return true;
        } else {
            return false;
        }
    }
    private function ifNotEmpty($name, $email, $subject, $message)
    {
        if ($name != "" && $email != "" && $subject != "" && $message != "") {
            return true;
        } else {
            return false;
        }
    }
    private function isNotEmpty($name, $email, $date, $time, $person)
    {
        if ($name != "" && $email != "" && $date != "" && $time != "" && $person != "") {
            return true;
        } else {
            return false;
        }
    }
    private function checkUserInformation($fname, $lname, $mname, $address, $cnumber, $email)
    {
        if ($fname != "" && $lname != "" && $mname != "" && $address != "" && $cnumber != "" && $email != "") {
            return true;
        } else {
            return false;
        }
    }
    private function checkNotLock($status,$isLocked,$user,$username,$password,$tmp)
    {
        if($status == "admin" && $isLocked == 0 && $user == $username && md5($password) == $tmp)
        {
            return "admin";
        }
        elseif($status == "client" && $isLocked == 0 && $user == $username && md5($password) == $tmp)
        {
            return "client";
        }
        elseif($status == "client" && $isLocked == 1 && $user == $username && md5($password) == $tmp)
        {
            return "lock";
        }
        else
        {
            return "error";
        }
    }

    //end


    //store to database!
    private function register($user, $pass, $fname, $lname, $mname, $address, $mobile_no, $email)
    {
        try {
            if ($this->checker($user, $pass, $fname, $lname, $mname, $address, $mobile_no, $email)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->insertQuery());
                    $stmt->execute(array($user, md5($pass), $fname, $lname, $mname, $address, $mobile_no, $email, 0, "client"));
                    $res = $stmt->fetch();
                    if (!$res) {
                        $conn->dbClose();
                        return 200;
                    } else {
                        $conn->dbClose();
                        return 404;
                    }
                } else {
                    return 403;
                }
            } else {
                return 403;
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function login($username, $password)
    {
        try {
            if ($this->checkUser($username, $password)) {
                $conn = new database();
                $tmp = md5($password);
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->selectQuery());
                    $stmt->execute(array($username, $tmp));
                    $result = $stmt->fetch();
                    $status = null;
                    $isLocked = null;
                    $user = null;
                    if ($result > 0) {
                        $_SESSION['username'] = $username;
                        $_SESSION['password'] = $tmp;
                        $status = $result['roles'];
                        $isLocked = $result['isLocked'];
                        $user = $result['username'];
                        $conn->dbClose();
                        return $this->checkNotLock($status,$isLocked,$user,$username,$password,$tmp);
                    } else {
                        return 404;
                    }
                } else {
                    return 403;
                }
            } else {
                return 403;
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function reset($username, $password, $new_password)
    {
        try {
            if ($this->checkResetCredentials($username, $password, $new_password)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->resetQuery());
                    $stmt->execute(array(md5($new_password), self::getId()));
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$result) {
                        $conn->dbClose();
                        return 1;
                    } else {
                        $conn->dbClose();
                        return 0;
                    }
                }
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function lockUser($attempt,$username)
    {
        try {
            $conn = new database();
            if ($conn->getStatus()) {
                $stmt = $conn->getCon()->prepare($this->lockQuery());
                $stmt->execute(array($attempt,$username));
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$result) {
                    $conn->dbClose();
                    return 200;
                } else {
                    $conn->dbClose();
                    return 404;
                }
                }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function coffee($coffee, $price, $type)
    {
        try {
            if ($this->ifValid($coffee, $price, $type)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->coffeeQuery());
                    $stmt->execute(array($this->getId(), $this->asDollar($price), $coffee, $type, "Sold"));
                    $res = $stmt->fetch();
                    if (!$res) {
                        $conn->dbClose();
                        return 200;
                    } else {
                        $conn->dbClose();
                        return 404;
                    }
                } else {
                    return 403;
                }
            } else {
                return 403;
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function message($name, $email, $subject, $message)
    {
        try {
            if ($this->ifNotEmpty($name, $email, $subject, $message)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->contactQuery());
                    $stmt->execute(array($this->getId(), $name, $email, $subject, $message));
                    $res = $stmt->fetch();
                    if (!$res) {
                        $conn->dbClose();
                        return 200;
                    } else {
                        $conn->dbClose();
                        return 404;
                    }
                } else {
                    return 403;
                }
            } else {
                return 403;
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function reserved($name, $email, $date, $time, $person)
    {
        try {
            if ($this->isNotEmpty($name, $email, $date, $time, $person)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->reservedQuery());
                    $stmt->execute(array($this->getId(), $name, $email, $date, $time, $person, "Pending"));
                    $res = $stmt->fetch();
                    if (!$res) {
                        $conn->dbClose();
                        return 200;
                    } else {
                        $conn->dbClose();
                        return 404;
                    }
                } else {
                    return 403;
                }
            } else {
                return 403;
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function viewReserve()
    {
        try {
            if ($this->checkUser($_SESSION['username'], $_SESSION['password'])) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->viewReserveQuery());
                    $stmt->execute(array());
                    $result = $stmt->fetchAll();
                    $conn->dbClose();
                    return json_encode($result);
                } else {
                    return "403";
                }
            } else {
                return "403";
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function viewCoffee()
    {
        try {
            if ($this->checkUser($_SESSION['username'], $_SESSION['password'])) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->viewCoffeeQuery());
                    $stmt->execute(array());
                    $result = $stmt->fetchAll();
                    $conn->dbClose();
                    return json_encode($result);
                } else {
                    return "403";
                }
            } else {
                return "403";
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function viewUser()
    {
        try {
            if ($this->checkUser($_SESSION['username'], $_SESSION['password'])) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->viewUserQuery());
                    $stmt->execute(array());
                    $result = $stmt->fetchAll();
                    $conn->dbClose();
                    return json_encode($result);
                } else {
                    return "403";
                }
            } else {
                return "403";
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function deleteInfo($user_id)
    {
        try {
            $conn = new database();
            if ($conn->getStatus()) {
                $stmt = $conn->getCon()->prepare($this->deleteQuery());
                $stmt->execute(array($user_id));
                if ($stmt) {
                    $conn->dbClose();
                    return 200;
                } else {
                    $conn->dbClose();
                    return 404;
                }
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function deleteCoff($id)
    {
        try {
            $conn = new database();
            if ($conn->getStatus()) {
                $stmt = $conn->getCon()->prepare($this->deleteCoffeeQuery());
                $stmt->execute(array($id));
                if ($stmt) {
                    $conn->dbClose();
                    return 200;
                } else {
                    $conn->dbClose();
                    return 404;
                }
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function updateInformation($user_id, $fname, $lname, $mname, $address, $cnumber, $email)
    {
        try {
            if ($this->checkUserInformation($fname, $lname, $mname, $address, $cnumber, $email)) {
                $conn = new database();
                if ($conn->getStatus()) {
                    $stmt = $conn->getCon()->prepare($this->updateUserInformation());
                    $stmt->execute(array($fname, $lname, $mname, $address, $cnumber, $email, $user_id));
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$result) {
                        $conn->dbClose();
                        return 200;
                    } else {
                        $conn->dbClose();
                        return 202;
                    }
                }
            }
        } catch (PDOException $th) {
            return $th;
        }
    }

    private function getId()
    {
        try {
            $db = new database();
            if ($db->getStatus()) {
                $stmt = $db->getCon()->prepare($this->selectQuery());
                $stmt->execute(array($_SESSION['username'], $_SESSION['password']));
                $tmp = null;
                $row = $stmt->fetch();
                if ($row > 0) {
                    $tmp = $row['user_id'];
                }
                return $tmp;
            }
        } catch (PDOException $th) {
            echo $th;
        }
    }
    //end

    private function asDollar($value)
    {
        if ($value < 0) {
            return "-" . $this->asDollar(-$value);
        } else {
            return '$' . number_format($value, 2);
        }
    }


    //user query
    private function insertQuery()
    {
        return "INSERT INTO `users`(`username`, `password`, `fname`, `lname`, `mname`, `address`, `contact_number`, `email`, `isLocked`, `roles`) VALUES (?,?,?,?,?,?,?,?,?,?)";
    }
    private function selectQuery()
    {
        return "SELECT * FROM users WHERE username = ? AND `password` = ?";
    }
    private function resetQuery()
    {
        return "UPDATE users SET `password` =? WHERE `user_id` =? ";
    }
    private function coffeeQuery()
    {
        return "INSERT INTO `coffee`(`user_id`, `Price`, `Name`, `Type`, `status`) VALUES (?,?,?,?,?)";
    }
    private function contactQuery()
    {
        return "INSERT INTO `contact`(`user_id`, `name`, `email`, `subject`, `message`) VALUES (?,?,?,?,?)";
    }
    private function reservedQuery()
    {
        return "INSERT INTO `reserved`(`user_id`, `name`, `email`, `date`, `time`, `person`, `status`) VALUES (?,?,?,?,?,?,?)";
    }

    private function viewQuery()
    {
        return "SELECT * FROM `reserved` WHERE `user_id` = ?";
    }

    private function lockQuery()
    {
        return "UPDATE users SET isLocked = ? WHERE username = ?";
    }

    //admin query
    private function viewUserQuery()
    {
        return "SELECT * FROM users";
    }

    private function viewReserveQuery()
    {
        return "SELECT * FROM reserved";
    }

    private function viewCoffeeQuery()
    {
        return "SELECT * FROM coffee";
    }

    private function updateUserInformation()
    {
        return "UPDATE users SET `fname` = ?, `lname` = ?, `mname` = ?, `address` = ?, `contact_number` = ?, `email` = ? WHERE `user_id` = ?";
    }

    private function deleteQuery()
    {
        return "DELETE FROM users WHERE user_id = ?";
    }

    private function deleteCoffeeQuery()
    {
        return "DELETE FROM coffee WHERE id = ?";
    }
}
