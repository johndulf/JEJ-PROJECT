<?php
define('server', 'localhost');
define('username', 'root');
define('password', '');
define('database', 'db_project');
