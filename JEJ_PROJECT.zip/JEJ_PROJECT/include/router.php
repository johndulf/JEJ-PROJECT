<?php
session_start();
require_once('backend.php');
if (isset($_POST['choice'])) {
    switch ($_POST['choice']) {
        case 'register':
            $register = new backend();
            echo $register->doRegister(
                $_POST['user'],
                $_POST['pass'],
                $_POST['fname'],
                $_POST['lname'],
                $_POST['mname'],
                $_POST['address'],
                $_POST['mobile_no'],
                $_POST['email']
            );
            break;
        case 'login':
            $login = new backend();
            echo $login->doLogin(
                $_POST['username'],
                $_POST['password']
            );
            break;
        case 'reset':
            $reset = new backend();
            echo $reset->doReset(
                $_POST['user'],
                $_POST['pass'],
                $_POST['npass']
            );
            break;
        case 'bookCoffee':
            $booking = new backend();
            echo $booking->doBook(
                $_POST['coffee'],
                $_POST['price'],
                $_POST['type']
            );
            break;
        case 'messages':
            $message = new backend();
            echo $message->doMessage(
                $_POST['name'],
                $_POST['email'],
                $_POST['subject'],
                $_POST['message']
            );
            break;
        case 'reserve':
            $reserve = new backend();
            echo $reserve->doReserve(
                $_POST['name'],
                $_POST['email'],
                $_POST['date1'],
                $_POST['time1'],
                $_POST['person']
            );
            break;
        case 'viewReserve':
            $view = new backend();
            echo $view->doViewReserve();
            break;
        case 'viewUser':
            $view = new backend();
            echo $view->doViewUser();
            break;
        case 'viewCoffee':
            $view = new backend();
            echo $view->doViewCoffee();
            break;
        case 'viewUser':
            $view = new backend();
            echo $view->doViewUser();
            break;
        case 'deleteInformation':
            $deleteInfo = new backend();
            echo $deleteInfo->deleteUser(
                $_POST['user_id']
            );
            break;
        case 'deleteCoffee':
            $deleteCof = new backend();
            echo $deleteCof->deleteCoffee(
                $_POST['id']
            );
            break;
        case 'updateInformation':
            $updateInfo = new backend();
            echo $updateInfo->updateUser(
                $_POST['user_id'],
                $_POST['fname'],
                $_POST['lname'],
                $_POST['mname'],
                $_POST['address'],
                $_POST['cnumber'],
                $_POST['email'],
            );
            break;
        case 'lockUser':
            $lock = new backend();
            echo $lock->doLockUser(
                $_POST['attempt'],
                $_POST['username']
            );
            break;
        case 'logout':
            session_unset();
            session_destroy();
            echo "200";
            break;
        default:
            # code...
            break;
    }
}
